const Signation = () => `
<tr>
  <td align="left"
    style="font-size:0px;padding:0px 25px 0px 25px;padding-top:0px;padding-right:25px;padding-bottom:0px;padding-left:25px;word-break:break-word;">
    <div
      style="font-family:Arial, sans-serif;font-size:14px;letter-spacing:normal;line-height:1;text-align:left;color:#000000;">
      <p class="text-build-content" data-testid="RB_XdJ1yXO"
        style="margin: 10px 0; margin-top: 10px; margin-bottom: 10px;"><span
          style="color:#282215;font-family:Roboto;font-size:15px;line-height:10px;"><i>The Vintage
            Poker Team</i></span></p>
    </div>
  </td>
</tr>
`;

module.exports = Signation;
