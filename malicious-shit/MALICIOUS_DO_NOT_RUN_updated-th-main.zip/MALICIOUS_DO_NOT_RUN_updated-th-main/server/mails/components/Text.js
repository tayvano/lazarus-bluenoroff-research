const Text = (textContent) => `
  <div style="font-family:Arial, sans-serif;font-size:15px;letter-spacing:normal;line-height:1;text-align:left;color:#000000;">
    <p class="text-build-content" data-testid="g-3gwNNsRl" style="margin: 10px 0; margin-top: 10px;">
      ${textContent}
    </p>
  </div>
`;

module.exports = Text;
