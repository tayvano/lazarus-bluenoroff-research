import { createContext } from 'react';

const offlineContext = createContext();

export default offlineContext;
