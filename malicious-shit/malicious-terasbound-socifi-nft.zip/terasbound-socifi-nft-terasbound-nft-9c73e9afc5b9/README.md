# Terasbound DEX

**Terasbound** is one of the most progressive decentralized exchanges (DEXs) in the DeFi space. Even amid market volatility, we continue building with a vision to empower users, improve liquidity, and grow sustainably.

---

We are committed to:

-  Deep analysis of DeFi industry trends
-  Efficient use of financial and human resources
-  Continuous innovation and new product launches
-  Community engagement and transparency

---

## Proposed Update: Trade Fee Adjustment

To fuel long-term growth and ecosystem development, we propose increasing the trade fee from **0.1% to 0.2%**.

###  Fee Distribution Breakdown (0.2% Total)

| Purpose                    | Allocation |
|----------------------------|------------|
|  LP Rewards              | 0.15%      |
|  TB Token Burn           | 0.01%      |
|  Terasbound Earn Pool    | 0.02%      |
|  Terasbound Team         | 0.02%      |

---

##  Why It Matters

###  Team Incentives

The team has worked for over a year without receiving trade fee revenue. This change enables fair compensation and motivates further innovation and maintenance.

###  TB Burn Mechanism

With over **36,938,270 TB tokens already burned**, the burn mechanism continues to reduce supply and increase scarcity, helping preserve value.

###  Increased LP Rewards

Boosting LP rewards will attract more liquidity, increase TVL (Total Value Locked), and reduce slippage for traders — all while enhancing user experience.


![alt text](public/terasbound.jpg)

![alt text](public/terasbound1.jpg)
###  Expanding TB Utilities

We’re building advanced tools to strengthen TB token utility:

- **Double Launchpools**
- **Multi-reward Pools**
- **Next-gen Launchpad**

---
![alt text](public/terasbound2.jpg)

##  Development Setup

### Install server dependencies

```bash
cd backend
yarn
```

### Install frontend dependencies

```bash
yarn
```

### Run project

```bash
yarn start
```