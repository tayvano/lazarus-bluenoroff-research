export {};
declare global {
  interface Window {
    ethereum: any;
  }
}
