All assets Python file should be updated if you want to change the Server Address.

