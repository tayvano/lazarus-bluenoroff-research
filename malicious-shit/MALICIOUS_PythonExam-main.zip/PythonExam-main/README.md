# Crypto Oracle
This project calculates the eth/btc price from market.
## Dependencies
Install requirements.
```
pip3 install -r requirements.txt
```
## Usage
```
python3 price.py
```