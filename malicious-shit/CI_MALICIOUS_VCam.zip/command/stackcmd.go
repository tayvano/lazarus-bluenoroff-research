package command

import (
	"encoding/base64"
	"strings"
)

const COMMAND_STACK_TOKEN = " "

func MakeMsg(id string, reqtype string, data [][]byte) string {

	encoded := make([]string, len(data)+2)

	encoded[0] = id
	encoded[1] = base64.StdEncoding.EncodeToString([]byte(reqtype))
	for index, elem := range data {
		encoded[index+2] = base64.StdEncoding.EncodeToString(elem)
	}

	line := strings.Join(encoded, COMMAND_STACK_TOKEN)

	return line
}

func DecodeMsg(msg string) (string, [][]byte) {

	encoded := strings.Split(msg, COMMAND_STACK_TOKEN)

	msgtype, _ := base64.StdEncoding.DecodeString(encoded[0])

	// has no data
	if len(encoded) == 1 {
		return string(msgtype), nil
	}

	// data exists
	data := make([][]byte, len(encoded)-1)

	for index, elem := range encoded[1:] {
		data[index], _ = base64.StdEncoding.DecodeString(elem)
	}

	return string(msgtype), data
}
