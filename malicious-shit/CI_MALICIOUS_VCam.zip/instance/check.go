package instance

import (
	"bits-project/bits/config"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"syscall"
	"time"
)

func CheckDupInstance() {
	pidfile := filepath.Join(os.TempDir(), config.PID_FILE_NAME)
	data, err := os.ReadFile(pidfile)
	if err != nil {
		return
	}

	pid, err := strconv.ParseInt(string(data), 10, 64)
	if err != nil {
		return
	}

	proc, err := os.FindProcess(int(pid))
	if err != nil {
		return
	}
	err = proc.Signal(syscall.Signal(0))

	if err != nil {
		if err.Error() == "os: process already finished" {
			return
		}

		errno, ok := err.(syscall.Errno)
		if !ok {
			return
		}
		if errno == syscall.ESRCH {
			return
		}
	}

	os.Exit(0)
}

func RegisterInstance() {
	pidfile := filepath.Join(os.TempDir(), config.PID_FILE_NAME)
	os.WriteFile(pidfile, []byte(fmt.Sprintf("%d", os.Getpid())), 0o644)
}

func Delay() {
	time.Sleep(time.Second * 10)
}
