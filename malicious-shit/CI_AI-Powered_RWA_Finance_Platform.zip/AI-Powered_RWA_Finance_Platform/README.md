# Product Overview

## ⚠️ Important

The `master` branch currently contains only the basic folder structure and configuration files (such as `package.json`, `.gitignore`, `postcss.config.js`, and `tailwind.config.js`). It does **not** reflect the latest development state of the project.

## 👉 Where to Find the Latest Code

All active development and up-to-date source code are available in the `dev` branch.

To switch to the latest version, run:

```bash
git checkout dev
```

## 📌 Summary

* `master` → minimal structure only (not up to date)
* `dev` → full implementation and current development progress

Please make sure you are working on or reviewing the `dev` branch.
